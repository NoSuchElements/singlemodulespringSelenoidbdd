package com.nosuchelements.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nosuchelements.config.QTestConfig;

import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.net.ssl.*;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Slf4j
@Component
public class QTestUtils {

	@Autowired
	private QTestConfig qtestConfig;

	private OkHttpClient httpClient;
	private final ObjectMapper objectMapper = new ObjectMapper();

	@PostConstruct
	public void init() throws Exception {
		httpClient = createOkHttpClientWithSSL();
		log.info("✅ QTestUtils initialized with SSL client");
	}

	/**
	 * 🔍 Find test run ID by TC name (e.g., "TC-1201") under parent cycle
	 * 
	 * @param tcName TC identifier like "TC-1201"
	 * @return testRunId if found, null if not found
	 */
	public Long findTestRunIdByTcNumber(String tcNumber) {
		try {
			String searchUrl = qtestConfig.getApiUrl() + "projects/" + qtestConfig.getProjectId() + "/test-runs"
					+ "?parentId=" + qtestConfig.getPlatformCycleId()
					+ "&parentType=test-cycle&f=100&s=0&expand=descendants";

			log.debug("🔍 Searching test runs for '{}': {}", tcNumber, searchUrl);

			Request request = new Request.Builder().url(searchUrl).get()
					.addHeader("Authorization", "Bearer " + qtestConfig.getApiToken()).build();

			try (Response response = httpClient.newCall(request).execute()) {
				if (!response.isSuccessful()) {
					log.warn("Search failed: HTTP {} - {}", response.code(), response.message());
					return null;
				}

				if (response.body() == null) {
					log.warn("Empty response body");
					return null;
				}

				String responseBody = response.body().string();
				JsonNode root = objectMapper.readTree(responseBody);
				JsonNode items = root.get("items");

				if (items == null || !items.isArray()) {
					log.warn("Invalid items structure in response");
					return null;
				}

				for (JsonNode item : items) {
					String name = item.get("name").asText();
					if (name.contains(tcNumber)) {
						Long testRunId = item.get("id").asLong();
						log.info("✅ Found test run {} for TC '{}': {}", testRunId, tcNumber, name);
						return testRunId;
					}
				}

				log.debug("No test run found for TC '{}'", tcNumber);
				return null;

			}
		} catch (Exception e) {
			log.error("❌ Error finding test run for TC '{}': {}", tcNumber, e.getMessage(), e);
			return null;
		}
	}

	/**
	 * 📋 Update test log result for given test run ID
	 * 
	 * @param testRunId Test run ID from findTestRunIdByTcName
	 * @param status    "Passed", "Failed", "Blocked", etc.
	 * @return true if successful
	 */
	public boolean updateTestLog(Long testRunId, String status) {
		try {
			String updateUrl = qtestConfig.getApiUrl() + "projects/" + qtestConfig.getProjectId() + "/test-runs/"
					+ testRunId + "/auto-test-logs";

			log.debug("📤 Updating test log: {} → {}", testRunId, status);

			// Match Postman exact format: seconds precision only
			String exeStart = Instant.now().minus(Duration.ofMinutes(5)).truncatedTo(ChronoUnit.SECONDS).toString();
			String exeEnd = Instant.now().truncatedTo(ChronoUnit.SECONDS).toString();

			String jsonBody = """
					{
					    "status": "%s",
					    "exe_start_date": "%s",
					    "exe_end_date": "%s"
					}
					""".formatted(status, exeStart, exeEnd);

			RequestBody body = RequestBody.create(jsonBody, MediaType.parse("application/json"));

			Request request = new Request.Builder().url(updateUrl).post(body)
					.addHeader("Authorization", "Bearer " + qtestConfig.getApiToken()).build();

			try (Response response = httpClient.newCall(request).execute()) {
				boolean success = response.isSuccessful();
				String responseBody = response.body() != null ? response.body().string() : "null";

				log.info("📋 Test log update {} for run {}: HTTP {} - {}", success ? "✅ SUCCESS" : "❌ FAILED",
						testRunId, response.code(), responseBody);

				return success;
			}
		} catch (Exception e) {
			log.error("❌ Error updating test log for run {}: {}", testRunId, e.getMessage(), e);
			return false;
		}
	}

	/**
	 * 🎯 Combined operation: Find + Update in one call
	 * 
	 * @param tcName TC identifier like "TC-1201"
	 * @param status "Passed", "Failed", etc.
	 * @return true if both operations succeeded
	 */
	public boolean updateTestLogByTcName(String tcName, String status) {
		log.info("🎯 Updating qTest for TC '{}' with status '{}'", tcName, status);

		Long testRunId = findTestRunIdByTcNumber(tcName);
		if (testRunId == null) {
			log.warn("❌ No test run found for TC '{}', skipping update", tcName);
			return false;
		}

		return updateTestLog(testRunId, status);
	}

	private OkHttpClient createOkHttpClientWithSSL() throws Exception {
		KeyStore truststore = KeyStore.getInstance(KeyStore.getDefaultType());
		try (FileInputStream instream = new FileInputStream(qtestConfig.getCertPath())) {
			truststore.load(instream, qtestConfig.getCertPassword().toCharArray());
		}

		TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		tmf.init(truststore);

		SSLContext sslContext = SSLContext.getInstance("TLS");
		sslContext.init(null, tmf.getTrustManagers(), null);

		return new OkHttpClient.Builder()
				.sslSocketFactory(sslContext.getSocketFactory(), (X509TrustManager) tmf.getTrustManagers()[0])
				.connectTimeout(Duration.ofSeconds(30)).readTimeout(Duration.ofSeconds(30)).build();
	}
}
