package com.nosuchelements.utils;

import okhttp3.*;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import javax.net.ssl.*;
import java.net.http.HttpClient;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.util.Map;

public class QTestSearchExample {

	private static final String BASE_URL = "";
	private static final String PROJECT_ID = "";
	private static final String PARENT_CYCLE_ID = "";
	private static final String ACCESS_TOKEN = "";

	private OkHttpClient createOkHttpClientWithSSL() throws Exception {
		// Your existing SSL setup
		KeyStore truststore = KeyStore.getInstance(KeyStore.getDefaultType());
		try (FileInputStream instream = new FileInputStream("C:\\Automation\\qTestCert\\qtest.jks")) {
			truststore.load(instream, "changeit".toCharArray());
		}

		TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		tmf.init(truststore);

		SSLContext sslContext = SSLContext.getInstance("TLS");
		sslContext.init(null, tmf.getTrustManagers(), null);

		// Create OkHttpClient with your SSL context
		return new OkHttpClient.Builder()
				.sslSocketFactory(sslContext.getSocketFactory(), (X509TrustManager) tmf.getTrustManagers()[0])
				.hostnameVerifier((hostname, session) -> true) // Add if hostname issues
				.connectTimeout(Duration.ofSeconds(30)).build();
	}
	public static void main(String[] args) throws Exception {
		QTestSearchExample qs = new QTestSearchExample();
		OkHttpClient client = qs.createOkHttpClientWithSSL();
		String tcName = "TC-1201";

		// 1️⃣ STEP 1: Find existing test run
		String searchUrl = BASE_URL + "/projects/" + PROJECT_ID + "/test-runs" + "?parentId=" + PARENT_CYCLE_ID
				+ "&parentType=test-cycle&f=100&s=0&expand=descendants";

		Request searchRequest = new Request.Builder().url(searchUrl).get()
				.addHeader("Authorization", "Bearer " + ACCESS_TOKEN).build();

		Long testRunId = null;
		try (Response searchResponse = client.newCall(searchRequest).execute()) {
			System.out.println("🔍 Search Status: " + searchResponse.code());
			System.out.println("🔍 Search Headers: " + searchResponse.headers());

			if (searchResponse.body() != null) {
				String searchBody = searchResponse.body().string();
				System.out.println("🔍 Search Response Length: " + searchBody.length() + " chars");
				System.out.println(
						"🔍 Search Response Preview: " + searchBody.substring(0, Math.min(500, searchBody.length())));

				ObjectMapper objectMapper = new ObjectMapper();
				JsonNode root = objectMapper.readTree(searchBody);
				JsonNode items = root.get("items");

				// Find test run containing TC-1201
				for (JsonNode item : items) {
					String name = item.get("name").asText();
					System.out.println("🔍 Checking: " + name + " (ID: " + item.get("id").asLong() + ")");
					if (name.contains(tcName)) {
						testRunId = item.get("id").asLong();
						System.out.println("✅ FOUND: TestRun ID " + testRunId + " → " + name);
						break;
					}
				}
			}
		}

		if (testRunId == null) {
			System.out.println("❌ No test run found for " + tcName);
			return;
		}

		System.out.println("🎯 Target TestRun ID: " + testRunId);

		// 2️⃣ Post test log result - Postman EXACT format
		String updateUrl = BASE_URL + "/projects/" + PROJECT_ID + "/test-runs/" + testRunId + "/auto-test-logs";
		System.out.println("📤 Update URL: " + updateUrl);

		// 🔧 MATCH POSTMAN: Seconds precision only
		String exeStart = Instant.now().minus(Duration.ofMinutes(5)).truncatedTo(ChronoUnit.SECONDS).toString();
		String exeEnd = Instant.now().truncatedTo(ChronoUnit.SECONDS).toString();

		String jsonBody = """
				{
				    "status": "Passed",
				    "exe_start_date": "%s",
				    "exe_end_date": "%s"
				}
				""".formatted(exeStart, exeEnd);

		System.out.println("📄 Request Body: " + jsonBody);

		RequestBody body = RequestBody.create(jsonBody, MediaType.parse("application/json"));
		Request updateRequest = new Request.Builder().url(updateUrl).post(body)
				.addHeader("Authorization", "Bearer " + ACCESS_TOKEN).build();

		try (Response updateResponse = client.newCall(updateRequest).execute()) {
			System.out.println("📋 Update Status: " + updateResponse.code());
			System.out.println("📋 Update Response: " + updateResponse.body().string());
		}
	}

}
