package com.nosuchelements.hooks;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import com.nosuchelements.config.QTestConfig;
import com.nosuchelements.utils.QTestUtils;
import com.nosuchelements.utils.ScreenshotHelper;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class QTestHooks {

	@Autowired
	private QTestConfig qtestConfig;

	@Autowired
	private QTestUtils qTestUtils;

	@Autowired(required = false)
	private ScreenshotHelper screenshotUtil; // Optional if not always available

	private static final Pattern QTEST_TAG_PATTERN = Pattern.compile("@QTEST_TC_(\\d+)");
	private static final ThreadLocal<String> CURRENT_TC_NAME = new ThreadLocal<>();

//	@Before
	public void beforeScenario(Scenario scenario) {
		// Quick exit if qTest is disabled
		if (!qtestConfig.isEnabled() || !qtestConfig.isConfigurationValid()) {
			return;
		}

		String tcNumber = extractTcNumber(scenario);
		if (tcNumber == null) {
			log.debug("No @QTEST_TC_* tag found: {}", scenario.getName());
			return;
		}

		// Store TC number for @After
		CURRENT_TC_NAME.set(tcNumber);
		log.info("🔗 qTest setup started for TC: {}", tcNumber);
	}

//	@After
	public void afterScenario(Scenario scenario) {
		String tcNumber = CURRENT_TC_NAME.get();
		if (tcNumber == null) {
			cleanupThreadLocal();
			return;
		}

		try {
			// 🎯 ONE LINE UPDATE using QTestUtils!
			String status = mapCucumberStatus(scenario.getStatus().name());
			boolean success = qTestUtils.updateTestLogByTcName(tcNumber, status);

			if (success) {
				log.info("✅ qTest updated successfully: TC-{} → {}", tcNumber, status);
			} else {
				log.warn("❌ qTest update failed/skipped: TC-{}", tcNumber);
			}

			// Optional: Attach screenshot on failure
			attachScreenshotIfFailed(scenario);

		} catch (Exception e) {
			log.error("❌ Unexpected error in qTest reporting for TC-{}: {}", tcNumber, e.getMessage(), e);
		} finally {
			cleanupThreadLocal();
		}
	}

	/**
	 * Extract TC number from @QTEST_TC_1234 tag
	 */
	private String extractTcNumber(Scenario scenario) {
		for (String tag : scenario.getSourceTagNames()) {
			Matcher matcher = QTEST_TAG_PATTERN.matcher(tag);
			if (matcher.matches()) {
				return "TC-" + matcher.group(1); // Convert to "TC-1234" format
			}
		}
		return null;
	}

	/**
	 * Map Cucumber status to qTest status
	 */
	private String mapCucumberStatus(String cucumberStatus) {
		return switch (cucumberStatus) {
		case "PASSED" -> "Passed";
		case "FAILED" -> "Failed";
		case "SKIPPED", "PENDING" -> "Blocked";
		default -> "No Run";
		};
	}

	/**
	 * Attach screenshot only on failure (optional feature)
	 */
	private void attachScreenshotIfFailed(Scenario scenario) {
		if (scenario.isFailed() && screenshotUtil != null && qtestConfig.isAttachScreenshots()) {
			try {
				String screenshotPath = screenshotUtil.captureScreenshot(scenario.getName());
				if (screenshotPath != null) {
					log.info("📸 Screenshot captured for failed scenario: {}", scenario.getName());
					// Cucumber automatically attaches screenshots via scenario.attach()
					// screenshotUtil.attachToScenario(scenario, screenshotPath);
				}
			} catch (Exception e) {
				log.warn("Screenshot capture failed: {}", e.getMessage());
			}
		}
	}

	/**
	 * Cleanup ThreadLocal storage
	 */
	private void cleanupThreadLocal() {
		CURRENT_TC_NAME.remove();
	}
}
